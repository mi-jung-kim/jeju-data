# 🍊 제주가 제철이야 (Jeju Seasonal Tourism)

> **"뻔한 인기 관광지가 아니라, 지금 이 순간 가장 빛나는 곳을 추천합니다."**  
> 제주 관광 이동 빅데이터 기반 **AI 제철 지수(Seasonal Lift)** 모델 & 인터랙티브 웹 큐레이션 서비스

---

## 📌 목차
1. [프로젝트 소개](#-프로젝트-소개)
2. [핵심 알고리즘: 제철 지수 (Seasonal Lift)](#-핵심-알고리즘-제철-지수-seasonal-lift)
3. [주요 기능](#-주요-기능)
4. [데이터 분석 및 파이프라인](#-데이터-분석-및-파이프라인)
5. [프로젝트 구조](#-프로젝트-구조)
6. [기술 스택](#-기술-스택)
7. [실행 및 배포 가이드](#-실행-및-배포-가이드)

---

## 📖 프로젝트 소개

기존 관광 추천 서비스는 **연간 누적 방문자 수**가 많은 유명 관광지(성산일출봉, 중문관광단지 등) 위주로 추천되어, 사계절 내내 동일한 장소만 노출되는 한계가 있었습니다.

**'제주가 제철이야'**는 제주 전역의 내비게이션 목적지 이동 빅데이터와 관광지 공간 데이터를 결합하여, **해당 시기(월별/계절별)에 방문 집중도가 평소 대비 급증하는 진짜 '제철' 명소**를 통계적으로 도출합니다.

- **봄(2~4월):** 산방산 유채꽃, 서우봉, 보롬왓 꽃밭
- **여름(7~8월):** 논짓물 담수욕장, 세기알해변, 원앙폭포
- **가을(10~11월):** 산굼부리 억새, 아끈다랑쉬오름, 새별오름
- **겨울(12~1월):** 동백포레스트, 제주동백수목원, 1100고지 설경

---

## 🧮 핵심 알고리즘: 제철 지수 (Seasonal Lift)

단순 방문객 수가 아닌, 제주도 전체 관광 수요의 계절적 변동을 통계적으로 보정한 지표입니다.

$$SL(p, m) = \frac{\text{관광지 } p\text{의 특정 월 } m \text{ 방문 비중 } S(p, m)}{\text{제주도 전체의 특정 월 } m \text{ 방문 비중 } B(m)}$$

- **$S(p, m)$ :** 특정 관광지 $p$의 연간 방문객 중 $m$월 방문객의 비율
- **$B(m)$ :** 제주도 전체 관광객 중 $m$월 총 방문객의 비율 (제주 관광 계절성 기준선, Baseline)

| 제철 지수 ($SL$) | 의미 및 해석 | 지도 핀 시각화 |
|---|---|:---:|
| **$SL \ge 2.0$** | 제주 전체 평균 대비 방문 집중도가 **2배 이상**인 극성수기 명소 | 🟢 진한 초록 |
| **$1.2 \le SL < 2.0$** | 계절적 요인으로 방문이 뚜렷하게 증가하는 명소 | 🟩 연한 초록 |
| **$0.8 \le SL < 1.2$** | 제주도 전체의 평균적인 계절 패턴과 유사한 수준 | 🟡 노란색 |
| **$SL < 0.8$** | 해당 월이 비수기인 명소 | 🟠 주황색 |

---

## ✨ 주요 기능

1. **이달의 제철 큐레이션 Top 3**
   - 선택한 월(1~12월)에 가장 제철도가 높은 상위 3개 관광지를 카드 형태로 추천
   - 계절 테마 뱃지, 제철 지수 배수(SL), 주소 및 상세 정보 표기
2. **동적 제철 컬러 핀 지도 시각화**
   - 제주 전역 787개 관광지 위치 표시
   - 선택한 월에 계산된 제철 지수에 따라 **주황색(비수기) ~ 초록색(제철)**으로 핀 색상 동적 변경
   - 핀 클릭 시 관광지명, 카테고리, 주소, 제철 지수를 컴팩트 팝업으로 제공
3. **오픈소스 지도 기반 (무료 & 무제한)**
   - API 키 제한이 없는 OpenStreetMap 및 Esri Canvas 기반 타일 레이어 지원
4. **제철 지수 인터랙티브 안내 모달**
   - 수식 원리와 모델 산출 배경을 직관적으로 확인할 수 있는 설명 모달

---

## 🔄 데이터 분석 및 파이프라인

```mermaid
flowchart TD
    A["제주 지역별 인기 장소 빅데이터\n(이동 데이터)"] --> C["match_places.py\n(지리/명칭 공간 매칭)"]
    B["Tourist_Area.csv\n(관광지 목록 & 좌표)"] --> C
    
    C --> D["Tourist_Nav_Match.csv\n(매칭 테이블)"]
    D --> E["analyze_v2.py\n(비관광 업종 필터링 & Seasonal Lift 산출)"]
    A --> E
    
    E --> F["calculated_seasonal_lift.csv\nrefined_seasonal_lift.csv"]
    F --> G["prepare_web_data.py\n(웹 최적화 JSON 생성)"]
    G --> H["web/static/data/web_data.json\n(프론트엔드 연동)"]
```

1. **공간 매칭 (`match_places.py`):**
   - 제주 관광지 목록과 내비게이션 목적지 명칭의 텍스트 유사도 및 거리(m)를 복합 계산하여 좌표 정밀 매칭
2. **계절성 모델링 (`analyze_v2.py`):**
   - 숙박/식당/카페/쇼핑 등 비관광 카테고리 제외
   - 12개월 이상 유효 데이터 및 총 방문수 임계치 필터링 후 월별 Baseline 대비 Lift 산출
3. **웹 데이터 서빙 (`prepare_web_data.py`):**
   - 프론트엔드에서 즉시 렌더링 가능한 경량 JSON 포맷으로 패키징

---

## 📁 프로젝트 구조

```
제주공모/
├── web/                           # 웹 프론트엔드 & 백엔드
│   ├── static/
│   │   ├── css/style.css          # Pretendard 폰트 기반 맞춤 UI 스타일
│   │   ├── js/app.js              # Leaflet 지도 제어 및 제철 핀 동적 렌더링
│   │   └── data/web_data.json     # 전수 관광지 제철지수 데이터셋
│   ├── templates/
│   │   └── index.html             # 메인 서비스 인터페이스
│   └── app.py                     # Flask 로컬 개발 서버
│
├── csv/                           # 핵심 데이터셋
│   ├── 제주 지역별 인기 장소.csv      # 원본 내비게이션 월별 방문 빅데이터 (56.9MB)
│   ├── Navigation_Info.csv        # 내비 목적지 명칭/주소 정보 (1.5MB)
│   ├── Tourist_Area.csv           # 제주 관광지 목록 및 공간 좌표 (86KB)
│   ├── Tourist_Nav_Match.csv      # 관광지-내비게이션 매칭 테이블 (162KB)
│   ├── calculated_seasonal_lift.csv # 140개소 전수 제철지수 계산 테이블 (325KB)
│   └── refined_seasonal_lift.csv  # 큐레이션 랭킹용 정제 테이블 (226KB)
│
├── match_places.py                # 지리 좌표 및 텍스트 매칭 파이프라인
├── analyze_v2.py                  # 제철 지수(Seasonal Lift) 산출 알고리즘
├── prepare_web_data.py            # 웹 데이터 빌드 스크립트
├── vercel.json                    # Vercel 무중단 정적/CDN 배포 설정
├── .gitignore                     # Git 제외 규칙
└── README.md                      # 프로젝트 문서
```

---

## 🛠️ 기술 스택

- **Analytics & Data Processing:** Python 3.10+, Pandas, NumPy
- **Frontend:** Vanilla JavaScript (ES6+), Leaflet.js 1.9, CSS3, HTML5
- **Backend & Serving:** Python Flask (Local Dev Server)
- **Deployment:** Vercel (Static / Serverless CDN Edge)

---

## 🚀 실행 및 배포 가이드

### 1. 로컬 환경에서 실행

```bash
# 1. 의존성 설치
pip install flask pandas requests

# 2. 로컬 웹 서버 구동
python web/app.py
```
- 브라우저에서 `http://localhost:5000` 접속

### 비짓제주 사진·태그·소개 붙이기 (선택)

1. `.env.example`을 복사해 `.env`로 이름을 바꾸고, 비짓제주 OPEN API 키를 넣습니다. `.env`는 git에 올라가지 않습니다.
2. 아래 순서로 실행합니다.

```bash
python fetch_visitjeju.py     # 비짓제주 관광지 정보 받기 → csv/VisitJeju_Places.csv
python match_visitjeju.py     # 우리 관광지와 이름·거리로 연결 → csv/Tourist_VisitJeju_Match.csv
python prepare_web_data.py    # 웹 데이터 다시 만들기 → web/static/data/web_data.json
python web/app.py
```

- `match_visitjeju.py`는 이름과 거리, 주소(읍·면·동, 리, 지번)를 함께 봅니다. 비짓제주 좌표가 틀린 곳(예: 동백포레스트 4km)도 이름과 주소가 맞으면 연결합니다.
- 실행이 끝나면 `csv/VisitJeju_Check.csv`에 추천 카드 관광지 전부의 상태(정상 / 연결 안 됨 / 사진 없음 / 검토 필요)와 비슷한 이름의 비짓제주 후보 3개가 적힙니다. 자동으로 못 찾거나 틀린 곳은 `match_visitjeju.py` 위쪽 `MANUAL` 표에 직접 적습니다.
- 사진·정보 출처: 비짓제주(제주관광공사). 화면에 출처를 표시합니다.

### 2. Vercel 원클릭 배포

본 프로젝트는 `vercel.json`을 통해 정적 웹 호스팅 환경에 최적화되어 있습니다.

1. 본 리포지토리를 **GitHub**에 Push합니다.
2. [Vercel](https://vercel.com/) 로그인 후 **"Add New Project"** 클릭
3. 해당 GitHub 리포지토리를 Import합니다.
4. 루트의 `vercel.json` 설정에 따라 빌드 단계 없이 즉시 글로벌 CDN에 배포됩니다.
