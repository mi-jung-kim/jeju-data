# 🍊 제주가 제철이야 (Jeju Seasonal Tourism)

> **"뻔한 인기 관광지가 아니라, 지금 이 순간 가장 빛나는 곳을 추천합니다."**  
> 제주 내비게이션 이동 빅데이터로 계산한 **제철 지수(Seasonal Lift)**와 비짓제주 관광정보를 묶은 월별 제철 관광지 웹 서비스

---

## 📌 목차
1. [프로젝트 소개](#-프로젝트-소개)
2. [핵심 지표: 제철 지수 (Seasonal Lift)](#-핵심-지표-제철-지수-seasonal-lift)
3. [주요 기능](#-주요-기능)
4. [데이터 분석 및 파이프라인](#-데이터-분석-및-파이프라인)
5. [프로젝트 구조](#-프로젝트-구조)
6. [기술 스택](#️-기술-스택)
7. [실행 및 배포 가이드](#-실행-및-배포-가이드)

---

## 📖 프로젝트 소개

기존 관광 추천 서비스는 **연간 누적 방문자 수**가 많은 유명 관광지(성산일출봉, 중문관광단지 등) 위주로 추천되어, 사계절 내내 동일한 장소만 노출되는 한계가 있었습니다.

**'제주가 제철이야'**는 제주관광빅데이터플랫폼의 내비게이션 목적지 도착 데이터(2024~2025년)와 데이터맵 제주의 관광지 위치를 결합해, **그 달에 평소보다 방문이 몰리는 '제철' 관광지**를 찾습니다. 추천 관광지에는 비짓제주 OPEN API의 사진·소개·태그·편의시설을 함께 보여 줍니다.

분석 결과로 나온 계절별 제철 관광지 예시 (괄호는 그 달 제철 지수):

- **겨울(12~1월):** 제주동백수목원(1월 6.08), 동백포레스트(12월 4.94)
- **봄(2~4월):** 산방산(3월 5.61), 서우봉(3월 2.80), 보롬왓수국길(4월 2.47)
- **여름(6~9월):** 보롬왓수국길(6월), 세기알해변(7·8월), 논짓물담수욕장(7·8월), 워터월드 제주(8월)
- **가을(10~11월):** 산굼부리(11월 3.65), 따라비오름(11월 3.29), 새별오름(11월 2.67)

---

## 🧮 핵심 지표: 제철 지수 (Seasonal Lift)

단순 방문객 수가 아니라, 제주 전체 관광 수요의 계절 변화를 나눠서 뺀 지표입니다. 학습 모델이 아니라 비율로 계산하는 통계 지표라서, 계산 과정을 그대로 설명할 수 있습니다.

$$SL(p, m) = \frac{\text{관광지 } p\text{의 특정 월 } m \text{ 방문 비중 } S(p, m)}{\text{제주도 전체의 특정 월 } m \text{ 방문 비중 } B(m)}$$

- **$S(p, m)$ :** 관광지 $p$의 2024~2025년 방문 중 $m$월 방문의 비중
- **$B(m)$ :** 매칭된 관광지 전체 방문 중 $m$월 방문의 비중 (제주 관광 계절성 기준선, Baseline)
- 월별 지수는 2024년과 2025년 같은 달 값의 평균입니다. 한 해에만 기록이 있는 달은 그 해 값을 씁니다.

| 제철 지수 ($SL$) | 의미 및 해석 | 지도 핀 시각화 |
|---|---|:---:|
| **$SL \ge 2.0$** | 제주 전체 평균 대비 방문 집중도가 **2배 이상**인 극성수기 명소 | 🟢 진한 초록 |
| **$1.2 \le SL < 2.0$** | 계절적 요인으로 방문이 뚜렷하게 증가하는 명소 | 🟩 연한 초록 |
| **$0.8 \le SL < 1.2$** | 제주도 전체의 평균적인 계절 패턴과 유사한 수준 | 🟡 노란색 |
| **$SL < 0.8$** | 해당 월이 비수기인 명소 | 🟠 주황색 |

---

## ✨ 주요 기능

1. **이달의 제철 관광지 Top 3**
   - 1~12월 중 여행 갈 달을 고르면 그 달 제철 지수 상위 3곳을 카드로 보여 줍니다 (처음 화면은 1월).
   - 카드에는 순위, 계절 테마, 제철 지수와 함께 비짓제주의 대표 사진·한 줄 소개·태그가 나옵니다.
2. **순위 핀과 상세 팝업**
   - 상위 3곳을 지도에 순위 핀으로 표시하고, 카드를 누르면 그 위치로 이동합니다.
   - 팝업에는 큰 사진, 소개, 편의시설(공용주차장, 장애인 화장실, 소요 시간 등)이 나옵니다.
3. **제철 지수 색 핀 지도**
   - 제주 관광지 787곳 위치를 표시하고, 제철 지수가 있는 87곳은 그 달 지수에 따라 **주황색(비수기) ~ 초록색(제철)**으로 칠합니다.
   - 비짓제주와 연결된 관광지는 팝업에 작은 사진과 태그가 나옵니다.
4. **비짓제주 관광정보 연결**
   - 비짓제주 OPEN API의 관광지 1,302곳을 이름·거리·주소로 우리 관광지와 연결합니다 (787곳 중 293곳, 추천 대상 87곳 중 81곳).
   - 사진·정보가 나오는 곳마다 출처 "사진·정보: 비짓제주(제주관광공사)"를 표시합니다.
5. **제철 지수 안내 창**
   - 계산 원리를 여행자에게 설명합니다.
6. **오픈소스 지도**
   - OpenStreetMap·Esri 타일을 써서 지도 API 키와 비용이 필요 없습니다.

---

## 🔄 데이터 분석 및 파이프라인

```mermaid
flowchart TD
    A["제주 지역별 인기 장소\n(내비 목적지 도착, 제주관광빅데이터플랫폼)"] --> C["match_places.py\n(이름·거리 매칭)"]
    B["Tourist_Area.csv\n(데이터맵 제주 관광지 787곳)"] --> C
    C --> D["Tourist_Nav_Match.csv\n(매칭 테이블)"]
    D --> E["analyze_v2.py\n(비관광 업종 제외 & 제철 지수 산출)"]
    A --> E
    E --> F["refined_seasonal_lift.csv"]
    V["비짓제주 OPEN API"] --> W["fetch_visitjeju.py"]
    W --> X["VisitJeju_Places.csv"]
    X --> Y["match_visitjeju.py\n(이름·거리·주소 연결)"]
    B --> Y
    Y --> Z["Tourist_VisitJeju_Match.csv\nVisitJeju_Check.csv(점검표)"]
    F --> G["prepare_web_data.py\n(웹용 JSON 생성)"]
    Z --> G
    G --> H["web/static/data/web_data.json"]
```

1. **공간 매칭 (`match_places.py`):** 관광지 이름과 내비 목적지 이름을 정규화(부속시설 접미어 제거, 해수욕장→해변 등)한 뒤 거리와 함께 비교해 연결합니다.
2. **제철 지수 산출 (`analyze_v2.py`):** 숙박·식당·카페·쇼핑 등 비관광 카테고리를 빼고, 데이터 12개월 이상·관광객 도착 1,000건 이상인 관광지에 대해 월별 지수를 구합니다.
3. **비짓제주 연결 (`fetch_visitjeju.py`, `match_visitjeju.py`):** 비짓제주 관광지를 받아 이름·거리·주소(읍·면·동, 리, 지번)로 연결하고, 판단이 필요한 짝은 점검표로 따로 뽑습니다.
4. **웹 데이터 생성 (`prepare_web_data.py`):** 월별 상위 10곳, 관광지 787곳 위치, 비짓제주 정보를 웹이 바로 읽는 JSON으로 만듭니다.

---

## 📁 프로젝트 구조

```
Jeju_In_Seasonal/
├── web/                           # 웹 (Vercel 배포 폴더)
│   ├── static/
│   │   ├── css/style.css          # 화면 스타일
│   │   ├── js/app.js              # Leaflet 지도, 카드·핀 렌더링
│   │   └── data/web_data.json     # 웹이 읽는 데이터
│   ├── templates/index.html       # 메인 화면
│   └── app.py                     # Flask 로컬 서버
│
├── csv/
│   ├── 제주 지역별 인기 장소.csv      # 원본 내비 도착 데이터 (2024~2025)
│   ├── Navigation_Info.csv        # 내비 목적지 이름·주소
│   ├── Tourist_Area.csv           # 관광지 787곳 이름·주소·좌표
│   ├── Tourist_Nav_Match.csv      # 관광지–내비 목적지 매칭 테이블
│   ├── calculated_seasonal_lift.csv # 1차 계산 (140곳)
│   ├── refined_seasonal_lift.csv  # 추천용 정제 결과 (91곳)
│   ├── VisitJeju_Places.csv       # 비짓제주 관광지 (API 결과)
│   ├── Tourist_VisitJeju_Match.csv # 관광지–비짓제주 연결 결과
│   └── VisitJeju_Check.csv        # 비짓제주 연결 점검표
│
├── crawl_places.py                # 데이터맵 제주 관광지 수집
├── match_places.py                # 관광지–내비 목적지 매칭
├── analyze_v2.py                  # 제철 지수 산출
├── fetch_visitjeju.py             # 비짓제주 OPEN API 받기
├── match_visitjeju.py             # 관광지–비짓제주 연결
├── prepare_web_data.py            # 웹 데이터 만들기
├── .env.example                   # API 키 예시 (.env는 git에 올리지 않음)
├── vercel.json                    # Vercel 배포 설정
└── README.md
```

---

## 🛠️ 기술 스택

- **Analytics & Data Processing:** Python 3.10+, Pandas, NumPy
- **Frontend:** Vanilla JavaScript (ES6+), Leaflet.js 1.9, CSS3, HTML5
- **Backend & Serving:** Python Flask (Local Dev Server)
- **Deployment:** Vercel (Static / Serverless CDN Edge)

---

## 🚀 실행 및 배포 가이드

### 1. 로컬 환경에서 실행

```bash
# 1. 의존성 설치
pip install flask pandas requests

# 2. 로컬 웹 서버 구동
python web/app.py
```
- 브라우저에서 `http://localhost:5000` 접속

### 비짓제주 사진·태그·소개 붙이기 (선택)

1. `.env.example`을 복사해 `.env`로 이름을 바꾸고, 비짓제주 OPEN API 키를 넣습니다. `.env`는 git에 올라가지 않습니다.
2. 아래 순서로 실행합니다.

```bash
python fetch_visitjeju.py     # 비짓제주 관광지 정보 받기 → csv/VisitJeju_Places.csv
python match_visitjeju.py     # 우리 관광지와 이름·거리로 연결 → csv/Tourist_VisitJeju_Match.csv
python prepare_web_data.py    # 웹 데이터 다시 만들기 → web/static/data/web_data.json
python web/app.py
```

- `match_visitjeju.py`는 이름과 거리, 주소(읍·면·동, 리, 지번)를 함께 봅니다. 비짓제주 좌표가 틀린 곳(예: 동백포레스트 4km)도 이름과 주소가 맞으면 연결합니다.
- 실행이 끝나면 `csv/VisitJeju_Check.csv`에 추천 카드 관광지 전부의 상태(정상 / 연결 안 됨 / 사진 없음 / 검토 필요)와 비슷한 이름의 비짓제주 후보 3개가 적힙니다. 자동으로 못 찾거나 틀린 곳은 `match_visitjeju.py` 위쪽 `MANUAL` 표에 직접 적습니다.
- 사진·정보 출처: 비짓제주(제주관광공사). 화면에 출처를 표시합니다.

### 2. Vercel 원클릭 배포

본 프로젝트는 `vercel.json`을 통해 정적 웹 호스팅 환경에 최적화되어 있습니다.

1. 본 리포지토리를 **GitHub**에 Push합니다.
2. [Vercel](https://vercel.com/) 로그인 후 **"Add New Project"** 클릭
3. 해당 GitHub 리포지토리를 Import합니다.
4. 루트의 `vercel.json` 설정에 따라 빌드 단계 없이 즉시 글로벌 CDN에 배포됩니다.
