// --- JeJeIya Web Application Logic ---

document.addEventListener('DOMContentLoaded', async () => {
  // State
  let webData = null;
  let currentMonth = 1; // 처음 화면은 1월
  let topMarkers = [];
  let backgroundMarkersGroup = L.layerGroup();
  let showBackgroundSpots = false;

  // 비짓제주 정보 표시용 (텍스트를 HTML로 넣기 전에 특수문자 처리)
  const esc = (v) => String(v ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const vjTags = (tags, n) => (tags && tags.length)
    ? `<div class="vj-tags">${tags.slice(0, n).map(t => `<span class="vj-tag">#${esc(t)}</span>`).join('')}</div>` : '';
  const vjCredit = '<div class="vj-credit">사진·정보: 비짓제주(제주관광공사)</div>';

  const monthDescriptions = {
    1: { title: "1월의 제주", desc: "붉은 동백꽃이 절정인 한겨울" },
    2: { title: "2월의 제주", desc: "산방산 유채꽃이 피기 시작하고 동백이 이어지는 달" },
    3: { title: "3월의 제주", desc: "화사한 노란 유채꽃이 온 섬을 물들이는 봄" },
    4: { title: "4월의 제주", desc: "초록빛 싱그러움과 봄꽃 향기 가득한 시기" },
    5: { title: "5월의 제주", desc: "신록의 푸르름과 청량한 숲길 트레킹" },
    6: { title: "6월의 제주", desc: "탐스러운 수국 꽃길과 초여름의 설렘" },
    7: { title: "7월의 제주", desc: "에메랄드빛 해변과 시원한 천연 담수욕" },
    8: { title: "8월의 제주", desc: "무더위를 날리는 신나는 바다 물놀이" },
    9: { title: "9월의 제주", desc: "선선한 바닷바람과 초가을의 여유" },
    10: { title: "10월의 제주", desc: "은빛 억새가 춤추는 가을 오름의 절정" },
    11: { title: "11월의 제주", desc: "억새가 가장 깊어지는 오름의 계절" },
    12: { title: "12월의 제주", desc: "한겨울을 밝히는 탐스러운 동백꽃의 향연" }
  };

  // 1. Initialize Map
  const jejuCenter = [33.375, 126.545];
  const map = L.map('map', {
    center: jejuCenter,
    zoom: 10,
    minZoom: 9,
    maxZoom: 17,
    zoomControl: false
  });

  // Position zoom controls cleanly at top-left
  L.control.zoom({ position: 'topleft' }).addTo(map);

  // 100% Free OpenStreetMap & Esri (Zero API key required!)
  const osmBaseLayer = L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png', {
    attribution: '&copy; <a href="https://www.openstreetmap.org/copyright" target="_blank">OpenStreetMap</a> contributors',
    maxZoom: 19
  });

  const esriGrayLayer = L.tileLayer('https://server.arcgisonline.com/ArcGIS/rest/services/Canvas/World_Light_Gray_Base/MapServer/tile/{z}/{y}/{x}', {
    attribution: 'Tiles &copy; Esri &mdash; Esri, DeLorme, NAVTEQ',
    maxZoom: 16
  });

  // Default: OpenStreetMap (Detailed, crisp Korean labels, no API key needed)
  osmBaseLayer.addTo(map);

  // Allow switching base layers cleanly if desired
  const baseLayers = {
    "표준 지도 (OSM)": osmBaseLayer,
    "부드러운 회색조 (Esri)": esriGrayLayer
  };
  L.control.layers(baseLayers, null, { position: 'topright' }).addTo(map);

  backgroundMarkersGroup.addTo(map);

  // Ensure map renders cleanly without any gray tiles
  setTimeout(() => {
    map.invalidateSize();
  }, 200);

  // 2. Fetch Data
  try {
    let res;
    try {
      res = await fetch('static/data/web_data.json', { cache: 'no-cache' });
      if (!res.ok) throw new Error('status ' + res.status);
    } catch {
      res = await fetch('/static/data/web_data.json', { cache: 'no-cache' });
    }
    webData = await res.json();
    console.log("Loaded web data successfully!", webData);
  } catch (err) {
    console.error("Failed to load data:", err);
    document.getElementById('recommendationCards').innerHTML = 
      '<div class="loading-state">데이터를 불러오는 중 오류가 발생했습니다.</div>';
    return;
  }

  // 3. Setup Month Pills
  const monthPillsContainer = document.getElementById('monthPills');
  for (let m = 1; m <= 12; m++) {
    const btn = document.createElement('button');
    btn.type = 'button';
    btn.className = `month-btn ${m === currentMonth ? 'active' : ''}`;
    btn.textContent = `${m}월`;
    btn.dataset.month = m;
    btn.setAttribute('aria-pressed', String(m === currentMonth));
    btn.addEventListener('click', () => setMonth(m));
    monthPillsContainer.appendChild(btn);
  }

  // Helper: Map seasonal lift value to a color (orange → green gradient)
  function getSeasonalColor(sl) {
    if (sl === null || sl === undefined) return '#94A3B8';
    if (sl >= 2.0) return '#059669';
    if (sl >= 1.5) return '#10B981';
    if (sl >= 1.2) return '#34D399';
    if (sl >= 1.0) return '#6EE7B7';
    if (sl >= 0.8) return '#FBBF24';
    if (sl >= 0.5) return '#F59E0B';
    return '#EA580C';
  }

  // Render background spots with seasonal-lift-colored pins
  function renderBackgroundSpots(m) {
    backgroundMarkersGroup.clearLayers();
    if (!webData || !webData.all_spots) return;

    webData.all_spots.forEach(spot => {
      // 그 달 제철 지수 (0.00도 값이다. 그 달 기록이 아예 없을 때만 null → 회색)
      const sl = (spot.monthly_sl && spot.monthly_sl[String(m)] !== undefined) ? spot.monthly_sl[String(m)] : null;
      const pinColor = getSeasonalColor(sl);

      const pinSvg = `
        <svg viewBox="0 0 24 36" xmlns="http://www.w3.org/2000/svg">
          <path d="M12 0C5.4 0 0 5.4 0 12c0 9 12 24 12 24s12-15 12-24C24 5.4 18.6 0 12 0z" fill="${pinColor}" stroke="#fff" stroke-width="1.5"/>
          <circle cx="12" cy="11" r="4.5" fill="#fff" opacity="0.85"/>
        </svg>`;

      const icon = L.divIcon({
        className: 'bg-spot-pin',
        html: pinSvg,
        iconSize: [20, 26],
        iconAnchor: [10, 26],
        popupAnchor: [0, -24]
      });

      const marker = L.marker([spot.lat, spot.lon], { icon: icon });
      const slText = sl !== null ? sl.toFixed(2) + '배' : '데이터 없음';
      const slBg = sl !== null ? pinColor + '22' : '#f1f5f9';
      const slFg = sl !== null ? pinColor : '#64748b';
      marker.bindPopup(`
        <div class="bg-spot-popup">
          ${spot.thumb ? `<img class="popup-photo popup-photo-sm" src="${esc(spot.thumb)}" alt="" loading="lazy" onerror="this.remove()">` : ''}
          <div class="popup-name">${spot.name}</div>
          <div class="popup-cat">${spot.category}${spot.address ? ' · ' + spot.address : ''}</div>
          <div class="popup-sl" style="background:${slBg};color:${slFg};">⚡ 제철지수 ${slText}</div>
          ${vjTags(spot.tags, 2)}
          ${spot.thumb ? vjCredit : ''}
        </div>
      `);
      backgroundMarkersGroup.addLayer(marker);
    });
  }

  // 5. Update Month & Recommendations
  function setMonth(m) {
    currentMonth = m;

    // Update Pill Active state
    document.querySelectorAll('.month-btn').forEach(btn => {
      const on = parseInt(btn.dataset.month) === m;
      btn.classList.toggle('active', on);
      btn.setAttribute('aria-pressed', String(on));
    });

    // Update Banner
    const info = monthDescriptions[m] || { title: `${m}월의 제주`, desc: "이달의 제철 여행지" };
    document.getElementById('bannerMonth').textContent = info.title;
    document.getElementById('bannerDesc').textContent = info.desc;

    // Render Cards and Markers
    renderRecommendations(m);

    // Re-render background spots if visible so colors reflect the new month
    if (showBackgroundSpots) renderBackgroundSpots(m);
  }

  // 6. Render Recommendations (Top 3)
  function renderRecommendations(m) {
    const container = document.getElementById('recommendationCards');
    container.innerHTML = '';

    // Clear previous top markers
    topMarkers.forEach(m => map.removeLayer(m));
    topMarkers = [];

    const monthList = (webData && webData.monthly && webData.monthly[m]) || [];
    const top3 = monthList.slice(0, 3);

    if (top3.length === 0) {
      container.innerHTML = '<div class="loading-state">추천 장소가 없습니다.</div>';
      return;
    }

    const bounds = L.latLngBounds();

    top3.forEach((item, index) => {
      const rank = index + 1;

      // Create Sidebar Card
      const card = document.createElement('div');
      card.className = `attraction-card card-rank-${rank}`;
      card.dataset.id = item.id;
      card.innerHTML = `
        ${item.photo ? `<img class="card-photo" src="${esc(item.photo.thumb || item.photo.url)}" alt="${esc(item.name)}" loading="lazy" onerror="this.remove()">` : ''}
        <div class="card-top-row">
          <span class="rank-badge rank-${rank}">${rank}위</span>
          <span class="category-tag">${item.category}</span>
        </div>
        <h3 class="card-title">${item.name}</h3>
        <p class="card-tagline">✨ ${item.tag}</p>
        ${item.intro ? `<p class="card-intro">${esc(item.intro)}</p>` : ''}
        ${vjTags(item.tags, 3)}
        <div class="card-metrics">
          <div class="metric-lift">
            <span class="lift-label">제철지수</span>
            <span class="lift-value">⚡ ${item.seasonal_lift.toFixed(2)}배</span>
          </div>
          <span class="card-address">${item.address || '제주특별자치도'}</span>
        </div>
        ${(item.photo || item.intro) ? vjCredit : ''}
      `;

      card.addEventListener('click', () => {
        focusOnAttraction(item, marker, card);
      });

      container.appendChild(card);

      // Create Custom Map Pin
      const icon = L.divIcon({
        className: 'custom-div-icon',
        html: `
          <div class="custom-pin rank-${rank}">
            <div class="pulse-ring"></div>
            ${rank}
          </div>
        `,
        iconSize: [36, 36],
        iconAnchor: [18, 18],
        popupAnchor: [0, -20]
      });

      const marker = L.marker([item.lat, item.lon], { icon: icon });

      // Create Popup Content
      const popupContent = `
        <div class="popup-card">
          ${item.photo ? `<img class="popup-photo" src="${esc(item.photo.url)}" alt="${esc(item.name)}" loading="lazy" onerror="this.remove()">` : ''}
          <div class="category-tag" style="margin-bottom:4px; display:inline-block;">${item.category} · ${rank}위 제철명소</div>
          <h4 class="popup-title">${item.name}</h4>
          <p class="popup-tag">✨ ${item.tag}</p>
          <div class="popup-metric">⚡ 제철지수(SL) ${item.seasonal_lift.toFixed(2)}배</div>
          ${item.intro ? `<p class="popup-intro">${esc(item.intro)}</p>` : ''}
          ${(item.facilities && item.facilities.length) ? `<div class="popup-facilities">${item.facilities.map(esc).join(' · ')}</div>` : ''}
          <div class="popup-address">${item.address}</div>
          ${(item.photo || item.intro) ? vjCredit : ''}
        </div>
      `;

      marker.bindPopup(popupContent);
      marker.addTo(map);
      topMarkers.push(marker);

      bounds.extend([item.lat, item.lon]);
    });

    // Fit map bounds to show all 3 items with padding
    if (bounds.isValid()) {
      map.fitBounds(bounds, { padding: [50, 50], maxZoom: 12 });
    }
  }

  // 7. Focus on a specific attraction
  function focusOnAttraction(item, marker, card) {
    // Highlight Card
    document.querySelectorAll('.attraction-card').forEach(c => c.classList.remove('active'));
    card.classList.add('active');

    // Pan map & open popup
    map.flyTo([item.lat, item.lon], 13, { duration: 1.2 });
    marker.openPopup();
  }

  // 8. Toggle All Background Spots
  const toggleAll = document.getElementById('toggleAllSpots');
  toggleAll.addEventListener('change', (e) => {
    showBackgroundSpots = e.target.checked;
    backgroundMarkersGroup.clearLayers();
    if (showBackgroundSpots) {
      renderBackgroundSpots(currentMonth);
    }
  });

  // 9. Reset Map View
  document.getElementById('resetMapBtn').addEventListener('click', () => {
    map.flyTo(jejuCenter, 10, { duration: 1 });
  });

  // 10. Info Modal Controls
  const modal = document.getElementById('infoModal');
  document.getElementById('infoModalBtn').addEventListener('click', () => modal.classList.add('show'));
  document.getElementById('closeModalBtn').addEventListener('click', () => modal.classList.remove('show'));
  document.getElementById('confirmModalBtn').addEventListener('click', () => modal.classList.remove('show'));
  modal.addEventListener('click', (e) => {
    if (e.target === modal) modal.classList.remove('show');
  });

  // Initial render (1월부터)
  setMonth(1);
});
