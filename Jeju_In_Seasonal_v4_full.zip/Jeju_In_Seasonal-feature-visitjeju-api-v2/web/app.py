import os
import json
from flask import Flask, render_template, jsonify, send_from_directory

app = Flask(__name__, 
            template_folder=os.path.join(os.path.dirname(__file__), 'templates'),
            static_folder=os.path.join(os.path.dirname(__file__), 'static'))

DATA_PATH = os.path.join(os.path.dirname(__file__), 'static', 'data', 'web_data.json')

def load_data():
    if os.path.exists(DATA_PATH):
        with open(DATA_PATH, 'r', encoding='utf-8') as f:
            return json.load(f)
    return {}

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/api/health')
def health():
    return jsonify({'status': 'ok', 'app': '제제이야 (JEJEIYA)', 'version': '0.9-beta'})

@app.route('/api/recommendations/<int:month>')
def recommendations(month):
    data = load_data()
    monthly = data.get('monthly', {})
    spots = monthly.get(str(month), monthly.get(month, []))
    return jsonify({
        'month': month,
        'recommendations': spots[:3],
        'all_top_ranked': spots
    })

if __name__ == '__main__':
    # Bind to 0.0.0.0 so local network devices (smartphones, colleagues on same Wi-Fi) can access
    port = int(os.environ.get('PORT', 5000))
    print(f"=======================================================")
    print(f"  제제이야 (JEJEIYA) - 제주가 제철이야 웹 서버 시작")
    print(f"  - 로컬 접속:   http://localhost:{port}")
    print(f"  - 네트워크 공유: http://172.30.1.33:{port}")
    print(f"=======================================================")
    app.run(host='0.0.0.0', port=port, debug=False)
