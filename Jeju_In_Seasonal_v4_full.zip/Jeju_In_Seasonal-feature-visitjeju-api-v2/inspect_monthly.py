import pandas as pd

df = pd.read_csv('csv/refined_seasonal_lift.csv')
match = pd.read_csv('csv/Tourist_Nav_Match.csv')

df['month'] = df['주행일자(YYYYMM)'].astype(str).str[-2:].astype(int)
df['year'] = df['주행일자(YYYYMM)'].astype(str).str[:4].astype(int)

agg = df.groupby(['관광지_idx', '관광지명', 'month']).agg({
    'Seasonal_Lift': 'mean',
    '관광객 도착 수': 'sum',
    '관광지_총방문': 'first'
}).reset_index()

coords = match[['관광지_idx', '관광지_위도', '관광지_경도', '관광지_지번주소', '내비_카테고리']].drop_duplicates(subset=['관광지_idx'])
agg = agg.merge(coords, on='관광지_idx', how='left')

output_lines = []
for m in range(1, 13):
    top_m = agg[agg['month'] == m].sort_values('Seasonal_Lift', ascending=False).head(5)
    output_lines.append(f"=== {m}월 Top 5 ===")
    for _, row in top_m.iterrows():
        output_lines.append(f"{row['관광지명']} | SL: {row['Seasonal_Lift']:.2f} | lat: {row['관광지_위도']}, lon: {row['관광지_경도']} | cat: {row['내비_카테고리']}")

with open('monthly_top.txt', 'w', encoding='utf-8') as f:
    f.write('\n'.join(output_lines))

print("Saved to monthly_top.txt")
