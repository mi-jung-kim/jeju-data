"""
데이터맵 제주(https://data.ijto.or.kr/bigdata/sub01.do) 관광지 목록 크롤러

수집 대상
  1) 지도 '관광지' 버튼 마커  : 사이트가 브라우저에서 실행하는 카카오맵 '관광명소(AT4)'
                                카테고리 검색을 동일한 좌표 격자(mapManager.categoryCoords)로 재현.
                                사이트는 좌표당 첫 페이지(15개)만 표시하지만, 여기서는 페이지를 넘겨
                                좌표당 최대 45개(카카오 상한)까지 수집하고 '지도표시' 열로 구분한다.
  2) 실시간 핫플레이스 Top10   : /api/datamap/tourinfo/tour-spot/ranking.do

중복 처리
  - 카카오 결과끼리는 카카오 장소 id 기준으로 1건만 남긴다.
  - 핫플레이스 장소가 카카오 결과와 같은 곳이면(이름 일치/포함 + 거리 기준) 한 행으로 병합한다.

출력: csv/Place_list.csv (UTF-8 BOM, 엑셀 호환)
"""
import math
import re
import time
from datetime import datetime
from pathlib import Path

import pandas as pd
import requests
import urllib3
from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.by import By
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support.ui import WebDriverWait

# 사이트가 중간 인증서를 내려주지 않아 requests 검증이 실패하므로 (공개 조회 API 한정) 검증을 끈다.
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

BASE = "https://data.ijto.or.kr"
PAGE_URL = f"{BASE}/bigdata/sub01.do"
RANKING_URL = f"{BASE}/api/datamap/tourinfo/tour-spot/ranking.do"
OUT_DIR = Path(r"C:\Users\justi\Desktop\제주공모\csv")
OUT_FILE = OUT_DIR / "Place_list.csv"
HEADERS = {"User-Agent": "Mozilla/5.0", "Referer": PAGE_URL}

# 지도 iframe 안에서 실행할 카카오 카테고리 검색 (페이지네이션 포함)
KAKAO_JS = r"""
const done = arguments[arguments.length - 1];
const ps = new kakao.maps.services.Places();
const coords = mapManager.categoryCoords;
const out = [];
const errors = [];
function runCoord(idx) {
  if (idx >= coords.length) { done({coords: coords, out: out, errors: errors}); return; }
  const c = coords[idx];
  let page = 0;
  const cb = (result, status, pagination) => {
    page++;
    if (status === kakao.maps.services.Status.OK) {
      result.forEach(r => out.push(Object.assign({}, r, {_coord: idx, _page: page})));
      if (pagination && pagination.hasNextPage) { setTimeout(() => pagination.nextPage(), 200); return; }
    } else if (status !== kakao.maps.services.Status.ZERO_RESULT) {
      errors.push({coord: idx, page: page, status: String(status)});
    }
    setTimeout(() => runCoord(idx + 1), 200);
  };
  ps.categorySearch('AT4', cb, {location: new kakao.maps.LatLng(c.lat, c.lng), radius: c.radius});
}
runCoord(0);
"""


def collect_kakao() -> pd.DataFrame:
    opts = Options()
    opts.add_argument("--headless=new")
    opts.add_argument("--window-size=1600,1000")
    opts.add_argument("--lang=ko-KR")
    driver = webdriver.Chrome(options=opts)
    try:
        driver.get(PAGE_URL)
        WebDriverWait(driver, 30).until(
            EC.frame_to_be_available_and_switch_to_it((By.ID, "iframeMap_LEFT"))
        )
        # MapManager 초기화(kakao.maps.load 이후) 대기
        WebDriverWait(driver, 60).until(
            lambda d: d.execute_script(
                "return typeof mapManager !== 'undefined' && !!mapManager && !!mapManager.categoryCoords"
            )
        )
        driver.set_script_timeout(600)
        res = driver.execute_async_script(KAKAO_JS)
    finally:
        driver.quit()

    print(f"[카카오] 검색 좌표 {len(res['coords'])}개, 원시 결과 {len(res['out'])}건, 오류 {len(res['errors'])}건")
    if res["errors"]:
        print("  오류 예시:", res["errors"][:5])

    raw = pd.DataFrame(res["out"])
    agg = (
        raw.groupby("id")
        .agg(
            지도표시=("_page", lambda s: bool((s == 1).any())),
            검색된_좌표수=("_coord", "nunique"),
        )
        .reset_index()
    )
    df = raw.drop_duplicates("id").drop(columns=["_coord", "_page", "distance"], errors="ignore")
    df = df.merge(agg, on="id")
    before = len(df)
    df = df[df["address_name"].fillna("").str.startswith("제주")]
    if before != len(df):
        print(f"  제주 외 주소 {before - len(df)}건 제외")
    print(f"[카카오] 중복 제거 후 {len(df)}곳 (지도에 실제 표시되는 첫 페이지 장소 {int(df['지도표시'].sum())}곳)")
    return df


def collect_hotplace() -> pd.DataFrame:
    r = requests.get(RANKING_URL, params={"popType": "tourist"}, headers=HEADERS, timeout=20, verify=False)
    r.raise_for_status()
    data = r.json().get("data") or []
    print(f"[핫플레이스] {len(data)}곳")
    return pd.DataFrame(data)


# ---------- 병합 ----------
def norm(s: str) -> str:
    return re.sub(r"[\s·\-_.]", "", str(s or ""))


def aliases(title: str) -> list[str]:
    """'성산일출봉(UNESCO 세계자연유산)(성산일출봉)' -> ['성산일출봉', 'UNESCO세계자연유산']"""
    main = re.sub(r"\(.*?\)", "", title)
    inner = re.findall(r"\((.*?)\)", title)
    out = [norm(main)] + [norm(x) for x in inner]
    return [a for a in dict.fromkeys(out) if len(a) >= 2]


def haversine_m(lat1, lon1, lat2, lon2) -> float:
    R = 6371000.0
    p1, p2 = math.radians(lat1), math.radians(lat2)
    dp, dl = p2 - p1, math.radians(lon2 - lon1)
    a = math.sin(dp / 2) ** 2 + math.cos(p1) * math.cos(p2) * math.sin(dl / 2) ** 2
    return 2 * R * math.asin(math.sqrt(a))


def match_hot_to_kakao(hot: pd.Series, kakao: pd.DataFrame):
    """이름 일치(0) > 이름 포함(1) 순, 같은 등급이면 가까운 곳. 거리 상한 = max(분석반경, 1500m)."""
    al = aliases(hot["title"])
    limit = max(float(hot.get("scope") or 0), 1500.0)
    best = None
    for idx, k in kakao.iterrows():
        kn = norm(k["place_name"])
        if any(a == kn for a in al):
            grade = 0
        elif any(a in kn or kn in a for a in al if len(kn) >= 2):
            grade = 1
        else:
            continue
        d = haversine_m(float(hot["lat"]), float(hot["lot"]), float(k["y"]), float(k["x"]))
        if d > limit:
            continue
        key = (grade, d)
        if best is None or key < best[0]:
            best = (key, idx)
    return None if best is None else (best[1], best[0][1])


def build(kakao: pd.DataFrame, hot: pd.DataFrame) -> pd.DataFrame:
    now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    rows = {}
    for _, k in kakao.iterrows():
        rows[k["id"]] = {
            "장소ID": f"KAKAO_{k['id']}",
            "장소명": k["place_name"],
            "출처": "카카오AT4",
            "카카오_분류": k.get("category_name"),
            "지번주소": k.get("address_name"),
            "도로명주소": k.get("road_address_name"),
            "전화번호": k.get("phone"),
            "위도": float(k["y"]),
            "경도": float(k["x"]),
            "카카오_URL": k.get("place_url"),
            "지도표시": bool(k["지도표시"]),
            "검색된_좌표수": int(k["검색된_좌표수"]),
        }

    used = set()
    for _, h in hot.iterrows():
        hot_fields = {
            "핫플_순위": h.get("rank"),
            "핫플_regSn": h.get("regSn"),
            "핫플_장소명": h.get("title"),
            "핫플_분석반경m": h.get("scope"),
            "핫플_실시간관광객수": h.get("totalPop"),
            "핫플_전일관광객수": h.get("lastDayPop"),
            "핫플_전일대비": h.get("popChange"),
            "핫플_기준시각": h.get("baseDt"),
            "썸네일URL": h.get("thumbnailpath"),
        }
        m = match_hot_to_kakao(h, kakao[~kakao["id"].isin(used)])
        if m is not None:
            kidx, dist = m
            kid = kakao.loc[kidx, "id"]
            used.add(kid)
            rows[kid].update(hot_fields)
            rows[kid]["출처"] = "카카오AT4+핫플레이스"
            print(f"  병합: {h['title']}  <->  {rows[kid]['장소명']}  ({dist:.0f}m)")
        else:
            rows[f"HOT_{h['regSn']}"] = {
                "장소ID": f"HOT_{h['regSn']}",
                "장소명": re.sub(r"\(.*?\)", "", h["title"]).strip() or h["title"],
                "출처": "핫플레이스",
                "위도": float(h["lat"]),
                "경도": float(h["lot"]),
                "지도표시": True,
                **hot_fields,
            }
            print(f"  단독(핫플레이스만): {h['title']}")

    cols = [
        "장소ID", "장소명", "출처", "카카오_분류", "지번주소", "도로명주소", "전화번호",
        "위도", "경도", "카카오_URL", "지도표시", "검색된_좌표수",
        "핫플_순위", "핫플_regSn", "핫플_장소명", "핫플_분석반경m",
        "핫플_실시간관광객수", "핫플_전일관광객수", "핫플_전일대비", "핫플_기준시각", "썸네일URL",
    ]
    df = pd.DataFrame(rows.values()).reindex(columns=cols)
    df["수집일시"] = now
    df = df.sort_values(["핫플_순위", "장소명"], na_position="last").reset_index(drop=True)
    return df


def main():
    t0 = time.time()
    kakao = collect_kakao()
    hot = collect_hotplace()
    df = build(kakao, hot)
    OUT_DIR.mkdir(parents=True, exist_ok=True)
    df.to_csv(OUT_FILE, index=False, encoding="utf-8-sig")
    print(f"\n저장 완료: {OUT_FILE}  ({len(df)}행, {time.time() - t0:.0f}초)")
    print(df["출처"].value_counts().to_string())


if __name__ == "__main__":
    main()
