"""
Tourist_Area.csv(관광지 787곳, 좌표 있음) ↔ Navigation_Info.csv(내비 목적지 월별 도착, 좌표 없음) 장소 매칭

1단계  내비 목적지 좌표 확보
       Navigation_Info.csv에는 좌표가 없으므로, 같은 TMAP 목적지 마스터를 쓰는
       데이터맵 제주 위치검색 API(/api/datamap/tmap/location.do)에서 목적지명으로 검색해
       '목적지명+주소'가 일치하는 항목의 좌표를 가져온다. (결과는 cache/에 저장해 재사용)

2단계  좌표 + 이름 기반 매칭 (관광지 1곳 ↔ 내비 목적지 여러 곳 허용)
       이름은 정규화한 '핵심명'으로 비교한다.
         - 괄호·공백·'/' 뒤 지점명 제거        (다이나믹메이즈/성읍점 → 다이나믹메이즈)
         - 앞뒤 '제주' 제거                    (워터월드 제주 ↔ 제주워터월드)
         - 유형 동의어 통일                    (해수욕장 → 해변, ○○악 → ○○오름)
         - 부속시설 접미어 제거                (함덕해수욕장주차장 → 함덕해변, 거문오름탐방안내소 → 거문오름)
       등급
         A 이름일치 : 핵심명이 같음                       거리 ≤ 3,000m (핵심명 3자 이하는 ≤ 1,000m)
         B 이름포함 : 한쪽 핵심명이 다른 쪽에 포함         거리 ≤ 1,000m  → 검토필요 표시
         C 이름유사 : 표기 차이(유사도 ≥ 0.75)            거리 ≤ 300m
       정리 규칙
         - 관광지에 A등급 매칭이 있으면 그 관광지의 B·C 매칭은 버린다.
         - 다른 관광지와 A등급으로 묶인 내비 목적지는 B·C 매칭에 쓰지 않는다.
       (좌표만 가까운 '근접' 매칭은 엉뚱한 시설이 붙는 문제가 커서 쓰지 않는다.)

출력  csv/Tourist_Nav_Match.csv  (관광지 × 매칭된 내비 목적지 1행씩, 미매칭 관광지도 1행 포함)
"""
import re
import time
from concurrent.futures import ThreadPoolExecutor
from difflib import SequenceMatcher
from pathlib import Path

import numpy as np
import pandas as pd
import requests
import urllib3

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

ROOT = Path(__file__).resolve().parent   # 저장소 폴더 (어느 컴퓨터에서든 동작)
CSV_DIR = ROOT / "csv"
CACHE = ROOT / "cache" / "nav_coords_cache.csv"
OUT_FILE = CSV_DIR / "Tourist_Nav_Match.csv"

API = "https://data.ijto.or.kr/api/datamap/tmap/location.do"
HEADERS = {"User-Agent": "Mozilla/5.0", "Referer": "https://data.ijto.or.kr/bigdata/sub01.do"}

# ---- 매칭 기준 (분포를 보고 조정) ----
A_RADIUS_M = 3000        # 이름일치 허용 거리
A_RADIUS_SHORT_M = 1000  # 핵심명이 짧을 때(흔한 이름: 민오름, 알오름 등)
SHORT_LEN = 3
B_RADIUS_M = 1000        # 이름포함 허용 거리
C_RADIUS_M = 300         # 이름유사 허용 거리
C_SIM_MIN = 0.75         # 이름유사 하한
D_RADIUS_M = 100         # 별칭추정: 같은 유형(오름/해변)이 이 거리 안에 있으면 같은 곳으로 추정
D_TYPES = ("오름", "해변")

# 부속시설 접미어 (긴 것부터 검사)
FACILITY_SUFFIXES = sorted([
    "정상전망대", "탐방안내소", "관광안내소", "안내소", "공영주차장", "제1주차장", "제2주차장", "주차장", "주차",
    "입구", "매표소", "정상", "전망대", "인증센터", "방문자센터", "종합관리센터", "관리센터", "쉼터", "탐방로",
], key=len, reverse=True)


# ---------------- 1단계: 내비 목적지 좌표 ----------------
def norm_addr(s: str) -> str:
    return re.sub(r"\s+", "", str(s or ""))


def lookup(name: str, addr: str) -> dict:
    """TMAP 목적지 마스터에서 (이름, 주소) 좌표 조회."""
    for attempt in range(3):
        try:
            r = requests.get(
                API,
                params={"geocoding": "Y", "pageUnit": 50, "pageIndex": 1, "searchKeyword": name},
                headers=HEADERS, timeout=20, verify=False,
            )
            items = (r.json().get("data") or {}).get("list") or []
            break
        except Exception:
            time.sleep(1 + attempt)
    else:
        return {"좌표출처": "조회실패"}

    a = norm_addr(addr)
    exact = [x for x in items if x["destName"] == name and norm_addr(x["destAddress"]) == a]
    same_name = [x for x in items if x["destName"] == name]
    same_addr = [x for x in items if norm_addr(x["destAddress"]) == a]
    for cand, label in ((exact, "이름+주소 일치"), (same_name, "이름 일치"), (same_addr, "주소 일치")):
        if cand:
            x = cand[0]
            return {"내비_위도": float(x["centerY"]), "내비_경도": float(x["centerX"]), "좌표출처": label,
                    "TMAP_목적지명": x["destName"], "TMAP_주소": x["destAddress"]}
    return {"좌표출처": "검색결과 없음"}


def get_nav_coords(nav: pd.DataFrame) -> pd.DataFrame:
    dests = nav[["목적지명", "목적지주소"]].drop_duplicates().reset_index(drop=True)
    cache = pd.read_csv(CACHE, encoding="utf-8-sig") if CACHE.exists() else pd.DataFrame(columns=["목적지명", "목적지주소", "좌표출처"])
    ok_cache = cache[cache["좌표출처"].isin(["이름+주소 일치", "이름 일치", "주소 일치", "검색결과 없음"])]
    todo = dests.merge(ok_cache[["목적지명", "목적지주소"]], how="left", indicator=True)
    todo = todo[todo["_merge"] == "left_only"][["목적지명", "목적지주소"]]
    print(f"[좌표] 내비 목적지 {len(dests)}곳 중 캐시 {len(dests) - len(todo)}곳, 신규 조회 {len(todo)}곳")

    if len(todo):
        with ThreadPoolExecutor(max_workers=4) as ex:
            res = list(ex.map(lambda t: lookup(*t), todo.itertuples(index=False, name=None)))
        new = pd.concat([todo.reset_index(drop=True), pd.DataFrame(res)], axis=1)
        cache = pd.concat([ok_cache, new], ignore_index=True).drop_duplicates(["목적지명", "목적지주소"], keep="last")
        CACHE.parent.mkdir(parents=True, exist_ok=True)
        cache.to_csv(CACHE, index=False, encoding="utf-8-sig")

    out = dests.merge(cache, on=["목적지명", "목적지주소"], how="left")
    print("[좌표] 좌표 출처 분포\n" + out["좌표출처"].value_counts(dropna=False).to_string())
    return out


# ---------------- 2단계: 이름 정규화 ----------------
def core_name(s: str) -> str:
    n = str(s or "")
    n = n.split("/")[0]                        # '/지점명' 제거
    n = re.sub(r"\(.*?\)", "", n)              # 괄호 제거
    n = re.sub(r"[\s·\-_.,&]", "", n)          # 공백·기호 제거
    n = re.sub(r"\d+$", "", n)                 # 끝 숫자 (전망대3)
    if n.startswith("제주") and len(n) - 2 >= 2:
        n = n[2:]
    if n.endswith("제주") and len(n) - 2 >= 2:
        n = n[:-2]
    changed = True
    while changed:                             # 부속시설 접미어 반복 제거
        changed = False
        for suf in FACILITY_SUFFIXES:
            if n.endswith(suf) and len(n) - len(suf) >= 2:
                n = n[: -len(suf)]
                changed = True
                break
    n = n.replace("해수욕장", "해변")           # 유형 동의어
    if n.endswith("악") and len(n) >= 3:
        n = n[:-1] + "오름"
    return n


def bigram_dice(a: str, b: str) -> float:
    A = {a[i:i + 2] for i in range(len(a) - 1)}
    B = {b[i:i + 2] for i in range(len(b) - 1)}
    return 2 * len(A & B) / (len(A) + len(B)) if A and B else 0.0


def grade(core_t: str, core_n: str, d: float):
    """(등급, 유사도) 또는 None"""
    if not core_t or not core_n:
        return None
    if core_t == core_n:
        limit = A_RADIUS_SHORT_M if len(core_t) <= SHORT_LEN else A_RADIUS_M
        return ("A 이름일치", 1.0) if d <= limit else None
    short, long_ = sorted((core_t, core_n), key=len)
    if len(short) >= 2 and short in long_:
        return ("B 이름포함", round(len(short) / len(long_), 3)) if d <= B_RADIUS_M else None
    sim = max(SequenceMatcher(None, core_t, core_n).ratio(), bigram_dice(core_t, core_n))
    if sim >= C_SIM_MIN and d <= C_RADIUS_M:
        return ("C 이름유사", round(sim, 3))
    if d <= D_RADIUS_M and any(core_t.endswith(k) and core_n.endswith(k) for k in D_TYPES):
        return ("D 별칭추정", round(sim, 3))
    return None


def haversine_matrix(lat1, lon1, lat2, lon2) -> np.ndarray:
    R = 6371000.0
    lat1, lon1, lat2, lon2 = map(np.radians, (lat1[:, None], lon1[:, None], lat2[None, :], lon2[None, :]))
    a = np.sin((lat2 - lat1) / 2) ** 2 + np.cos(lat1) * np.cos(lat2) * np.sin((lon2 - lon1) / 2) ** 2
    return 2 * R * np.arcsin(np.sqrt(a))


# ---------------- 실행 ----------------
def main():
    tour = pd.read_csv(CSV_DIR / "Tourist_Area.csv", encoding="utf-8-sig")
    nav = pd.read_csv(CSV_DIR / "Navigation_Info.csv", encoding="utf-8-sig")

    coords = get_nav_coords(nav)
    meta = (
        nav.groupby(["목적지명", "목적지주소"])
        .agg(내비_카테고리=("카테고리 3단계", lambda s: s.mode().iat[0]),
             내비_읍면동=("읍면동명", "first"),
             내비_데이터개월수=("주행일자(YYYYMM)", "nunique"),
             내비_총도착건수=("도착건수", "sum"))
        .reset_index()
    )
    dest = coords.merge(meta, on=["목적지명", "목적지주소"]).dropna(subset=["내비_위도", "내비_경도"]).reset_index(drop=True)
    n_nocoord = coords["내비_위도"].isna().sum()

    tour["_core"] = tour["장소명"].map(core_name)
    dest["_core"] = dest["목적지명"].map(core_name)
    D = haversine_matrix(tour["위도"].to_numpy(), tour["경도"].to_numpy(),
                         dest["내비_위도"].to_numpy(), dest["내비_경도"].to_numpy())

    # 후보 생성
    cands = []
    for i in range(len(tour)):
        for j in np.where(D[i] <= A_RADIUS_M)[0]:
            g = grade(tour.at[i, "_core"], dest.at[j, "_core"], float(D[i, j]))
            if g:
                cands.append((i, int(j), g[0], g[1], float(D[i, j])))
    c = pd.DataFrame(cands, columns=["ti", "dj", "매칭유형", "이름유사도", "거리_m"])

    # 정리 규칙
    is_a = c["매칭유형"].str.startswith("A")
    tour_with_a = set(c.loc[is_a, "ti"])
    dest_with_a = set(c.loc[is_a, "dj"])
    keep = is_a | (~c["ti"].isin(tour_with_a) & ~c["dj"].isin(dest_with_a))
    c = c[keep].copy()

    # 출력 조립
    t_cols = tour[["장소명", "지번주소", "위도", "경도"]].rename(columns={
        "장소명": "관광지명", "지번주소": "관광지_지번주소", "위도": "관광지_위도", "경도": "관광지_경도"})
    d_cols = dest.rename(columns={"목적지명": "내비_목적지명", "목적지주소": "내비_목적지주소"})[
        ["내비_목적지명", "내비_목적지주소", "내비_위도", "내비_경도", "좌표출처",
         "내비_카테고리", "내비_읍면동", "내비_데이터개월수", "내비_총도착건수"]]
    matched = (c.join(t_cols, on="ti").join(d_cols, on="dj").rename(columns={"ti": "관광지_idx"}).drop(columns="dj"))
    unmatched_idx = sorted(set(range(len(tour))) - set(c["ti"]))
    unmatched = t_cols.loc[unmatched_idx].assign(관광지_idx=unmatched_idx, 매칭유형="미매칭")
    out = pd.concat([matched, unmatched], ignore_index=True)

    out["거리_m"] = out["거리_m"].round(1)
    out["관광지_핵심명"] = tour["_core"].reindex(out["관광지_idx"]).to_numpy()
    out["검토필요"] = out["매칭유형"].str.startswith("B")
    m = out["매칭유형"] != "미매칭"
    out.loc[m, "내비_배정관광지수"] = out[m].groupby(["내비_목적지명", "내비_목적지주소"])["관광지_idx"].transform("nunique")
    out["관광지_매칭목적지수"] = out.groupby("관광지_idx")["내비_목적지명"].transform("count")

    cols = ["관광지_idx", "관광지명", "관광지_핵심명", "관광지_지번주소", "관광지_위도", "관광지_경도",
            "매칭유형", "검토필요", "거리_m", "이름유사도",
            "내비_목적지명", "내비_목적지주소", "내비_위도", "내비_경도", "좌표출처",
            "내비_카테고리", "내비_읍면동", "내비_데이터개월수", "내비_총도착건수",
            "관광지_매칭목적지수", "내비_배정관광지수"]
    out = out[cols].sort_values(["관광지_idx", "매칭유형", "거리_m"]).reset_index(drop=True)
    out.to_csv(OUT_FILE, index=False, encoding="utf-8-sig")
    m = out["매칭유형"] != "미매칭"

    n_t = len(tour)
    n_m = out.loc[m, "관광지_idx"].nunique()
    print(f"\n저장: {OUT_FILE} ({len(out)}행)")
    print(f"관광지 {n_t}곳 중 매칭 {n_m}곳 ({n_m / n_t:.1%}), 미매칭 {n_t - n_m}곳")
    print(out["매칭유형"].value_counts().to_string())
    print(f"검토필요(B) {int(out['검토필요'].sum())}행")
    print(f"내비 목적지 {len(coords)}곳 중 좌표 확보 {len(dest)}곳(미확보 {n_nocoord}곳), "
          f"관광지에 연결된 곳 {out.loc[m, ['내비_목적지명', '내비_목적지주소']].drop_duplicates().shape[0]}곳")


if __name__ == "__main__":
    main()
