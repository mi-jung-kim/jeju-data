import pandas as pd
import os

data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "csv")

print("Loading Dataset B (제주 지역별 인기 장소)...")
df_b = pd.read_csv(os.path.join(data_dir, "제주 지역별 인기 장소.csv"), encoding='utf-8')

print("Loading Dataset A Match Table (Tourist_Nav_Match)...")
df_match = pd.read_csv(os.path.join(data_dir, "Tourist_Nav_Match.csv"), encoding='utf-8')
df_match_valid = df_match[df_match['매칭유형'] != '미매칭']

print("Merging Datasets...")
df_merged = pd.merge(df_b, df_match_valid, left_on=['목적지명', '목적지주소'], right_on=['내비_목적지명', '내비_목적지주소'], how='inner')

# Category filtering: remove food/accomodation, but KEEP theme parks and natural spots
exclude_keywords = ['음식', '식당', '카페', '커피', '제과', '베이커리', '한식', '중식', '일식', '양식', '술집', '선술집', '숙박', '모텔', '펜션', '호텔', '리조트', '마트', '편의점', '미용실', '쇼핑']

def is_excluded(cat):
    if pd.isna(cat):
        return False
    cat_str = str(cat)
    for kw in exclude_keywords:
        if kw in cat_str:
            return True
    return False

print("Filtering categories...")
df_merged['exclude'] = df_merged['카테고리 3단계'].apply(is_excluded)
df_merged = df_merged[~df_merged['exclude']]

print("Calculating Baseline B(y,m)...")
baseline_visits = df_merged.groupby('주행일자(YYYYMM)')['관광객 도착 수'].sum().reset_index()
baseline_visits.rename(columns={'관광객 도착 수': '제주전체_관광객_방문'}, inplace=True)
total_baseline_visits = baseline_visits['제주전체_관광객_방문'].sum()
baseline_visits['B_ratio'] = baseline_visits['제주전체_관광객_방문'] / total_baseline_visits

print("Calculating S(p,y,m) and Seasonal Lift...")
attraction_monthly = df_merged.groupby(['관광지_idx', '관광지명', '주행일자(YYYYMM)'])['관광객 도착 수'].sum().reset_index()

# Filter 1: Minimum month count >= 12
month_counts = attraction_monthly.groupby('관광지_idx')['주행일자(YYYYMM)'].nunique().reset_index()
month_counts.rename(columns={'주행일자(YYYYMM)': '영업_월수'}, inplace=True)
valid_spots_months = month_counts[month_counts['영업_월수'] >= 12]['관광지_idx']

# Filter 2: Total visits >= 1000
attraction_total = attraction_monthly.groupby(['관광지_idx'])['관광객 도착 수'].sum().reset_index()
attraction_total.rename(columns={'관광객 도착 수': '관광지_총방문'}, inplace=True)
valid_spots_visits = attraction_total[attraction_total['관광지_총방문'] >= 1000]['관광지_idx']

# Intersect valid spots
valid_idx = set(valid_spots_months).intersection(set(valid_spots_visits))

# Apply filters
attraction_monthly = attraction_monthly[attraction_monthly['관광지_idx'].isin(valid_idx)]
attraction_total = attraction_total[attraction_total['관광지_idx'].isin(valid_idx)]

attraction_monthly = pd.merge(attraction_monthly, attraction_total, on='관광지_idx')
attraction_monthly['S_ratio'] = attraction_monthly['관광객 도착 수'] / attraction_monthly['관광지_총방문']

# Calculate Seasonal Lift
final_df = pd.merge(attraction_monthly, baseline_visits, on='주행일자(YYYYMM)')
final_df['Seasonal_Lift'] = final_df['S_ratio'] / final_df['B_ratio']

final_df.to_csv(os.path.join(data_dir, "refined_seasonal_lift.csv"), index=False, encoding='utf-8-sig')

print("\n--- Top 5 Peak Months (Highest Seasonal Lift) ---")
top_5 = final_df.sort_values('Seasonal_Lift', ascending=False).head(5)
print(top_5[['주행일자(YYYYMM)', '관광지명', '관광지_총방문', 'Seasonal_Lift']])

print("\nRefined analysis complete. Saved to refined_seasonal_lift.csv")
