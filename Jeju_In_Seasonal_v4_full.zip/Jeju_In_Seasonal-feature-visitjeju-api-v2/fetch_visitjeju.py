"""
비짓제주 관광정보 OPEN API(제주관광공사)에서 관광지(c1) 정보를 받아 csv/VisitJeju_Places.csv로 저장한다.
관광지 목록(Tourist_Area.csv)과 분석은 건드리지 않는다. 화면에 띄울 사진·태그·소개를 받는 용도다.

API   http://api.visitjeju.net/vsjApi/contents/searchList  (활용가이드 V1.1)
      변수: apiKey, locale, page, cid — 분류를 거르는 변수가 없어 전체를 받고 관광지(c1)만 남긴다.
키    환경변수 VISITJEJU_API_KEY 또는 저장소 맨 위 .env 파일의 VISITJEJU_API_KEY=... (.env는 git에 안 올라감)
다음  python match_visitjeju.py → python prepare_web_data.py
"""
import json
import os
import time
from pathlib import Path

import pandas as pd
import requests

ROOT = Path(__file__).resolve().parent
OUT = ROOT / "csv" / "VisitJeju_Places.csv"
API = os.environ.get("VISITJEJU_API_URL", "http://api.visitjeju.net/vsjApi/contents/searchList")
TOURIST_CODE = "c1"      # contentscd.value: c1 = 관광지
PAUSE = 0.2              # 초당 30건 한도 → 쪽마다 쉰다


def api_key() -> str:
    key = os.environ.get("VISITJEJU_API_KEY")
    env = ROOT / ".env"
    if not key and env.exists():
        for line in env.read_text(encoding="utf-8").splitlines():
            if line.strip().startswith("VISITJEJU_API_KEY="):
                key = line.split("=", 1)[1].strip().strip('"').strip("'")
    if not key:
        raise SystemExit("VISITJEJU_API_KEY가 없습니다. 환경변수나 .env 파일에 넣어 주세요.")
    return key


def get_page(key: str, page: int) -> dict:
    # 가이드 표에는 'apikey', 요청 예제에는 'apiKey'로 적혀 있어 둘 다 보낸다.
    params = {"apiKey": key, "apikey": key, "locale": "kr", "page": page}
    for attempt in range(3):
        try:
            r = requests.get(API, params=params, timeout=30)
            r.raise_for_status()
            return r.json()
        except (requests.RequestException, json.JSONDecodeError) as e:
            if attempt == 2:
                raise SystemExit(f"{page}쪽 요청 실패: {e}")
            time.sleep(1 + attempt)


def label(code) -> str:
    return (code or {}).get("label") or ""


def main():
    key = api_key()
    first = get_page(key, 1)
    if not first.get("items") and str(first.get("result")) not in ("00", "200"):
        raise SystemExit(f"API 오류: {first.get('result')} {first.get('resultMessage')}")
    pages = int(first.get("pageCount") or 1)
    print(f"[비짓제주] 전체 {first.get('totalCount')}건, {pages}쪽")

    items = list(first.get("items") or [])
    for p in range(2, pages + 1):
        time.sleep(PAUSE)
        items += get_page(key, p).get("items") or []
        if p % 10 == 0:
            print(f"  {p}/{pages}쪽")

    rows = []
    for it in items:
        if (it.get("contentscd") or {}).get("value") != TOURIST_CODE:
            continue
        lat, lon = it.get("latitude"), it.get("longitude")
        photo = (it.get("repPhoto") or {}).get("photoid") or {}
        rows.append({
            "콘텐츠ID": it.get("contentsid"),
            "이름": it.get("title"),
            "지번주소": it.get("address"),
            "도로명주소": it.get("roadaddress"),
            "시": label(it.get("region1cd")),
            "지역": label(it.get("region2cd")),
            "위도": float(lat) if lat else None,
            "경도": float(lon) if lon else None,
            "태그": it.get("tag"),
            "전체태그": it.get("alltag"),
            "소개": it.get("introduction"),
            "전화번호": it.get("phoneno"),
            "사진": photo.get("imgpath"),
            "썸네일": photo.get("thumbnailpath"),
        })

    df = pd.DataFrame(rows).drop_duplicates("콘텐츠ID")
    OUT.parent.mkdir(exist_ok=True)
    df.to_csv(OUT, index=False, encoding="utf-8-sig")
    print(f"저장: {OUT.relative_to(ROOT)} · 관광지(c1) {len(df)}곳 (좌표 있는 곳 {df['위도'].notna().sum()}곳, 사진 있는 곳 {df['사진'].notna().sum()}곳)")


if __name__ == "__main__":
    main()
