"""
관광지 787곳(Tourist_Area.csv) ↔ 비짓제주 관광지(VisitJeju_Places.csv) 연결

비짓제주 좌표가 실제 위치와 수 km 어긋난 곳(예: 동백포레스트 4km)이 있어서
거리만 보지 않고 주소(읍·면·동, 리, 지번)도 함께 본다.

연결 규칙 (관광지 1곳당 비짓제주 1곳. 위에 있는 규칙이 우선, 같은 규칙이면 가까운 곳)
  0 직접지정  : MANUAL 표에 적은 짝 (자동으로 못 찾거나 틀린 곳을 사람이 고칠 때)
  A 이름일치  : 핵심명이 같고, [거리 ≤ 2km(핵심명 3자 이하는 700m)] 또는 [같은 읍·면·동]
  B 이름포함  : 한쪽 핵심명이 다른 쪽에 포함되고, [거리 ≤ 700m] 또는 [같은 리, 짧은 쪽 3자 이상, 남는 글자가 길·탐방로 등]
  C 이름유사  : 유사도 ≥ 0.75이고 거리 ≤ 300m, 또는 유사도 ≥ 0.85이고 같은 리
  E 유형만다름: 끝의 유형(담수욕장·공원·해변 등)을 떼면 이름이 같고, 같은 리·동이고 1.5km 안 → 검토 필요
  D 지번일치  : 이름은 달라도 지번(번지까지)이 완전히 같음. 그 지번에 양쪽 모두 한 곳만 있을 때 → 검토 필요로 표시
  B에서 남는 글자가 랜드·파크·타운·관광 등이면 다른 시설로 보고 연결하지 않는다.
같은 이름이라도 다른 읍·면·동이고 멀면 연결하지 않는다 (예: 이름이 같은 다른 오름).

출력
  csv/Tourist_VisitJeju_Match.csv  관광지 787곳의 연결 결과 (prepare_web_data.py가 읽음)
  csv/VisitJeju_Check.csv          제철 지수가 있는 관광지 전부의 점검표
                                   (연결 안 됨 / 사진 없음 / 검토 필요 + 이름이 비슷한 비짓제주 후보 3개)
"""
from difflib import SequenceMatcher
from pathlib import Path
import re

import numpy as np
import pandas as pd

from match_places import bigram_dice, core_name

ROOT = Path(__file__).resolve().parent
CSV_DIR = ROOT / "csv"

A_RADIUS_M, A_RADIUS_SHORT_M, SHORT_LEN = 2000, 700, 3
B_RADIUS_M = 700
C_RADIUS_M, C_SIM_MIN, C_SIM_SAME_RI = 300, 0.75, 0.85

# 이름포함(B)에서 남는 글자에 이 말이 있으면 다른 시설로 본다 (산방산랜드 ≠ 산방산, 새별오름관광타운 ≠ 새별오름)
OTHER_FACILITY = ["랜드", "파크", "타운", "관광", "농원", "농장", "리조트", "센터", "카페", "월드", "프렌즈",
                  "하우스", "박물관", "미술관", "체험", "목장", "승마", "식물원", "테마", "펜션", "호텔", "온천",
                  "스파", "마을", "쉼터", "주차장", "휴게소"]
# 좌표가 700m 넘게 어긋나도 이름포함(B)으로 잇는 경우: 같은 리이고, 남는 글자가 길·탐방로 같은 말일 때만 (보롬왓수국길 = 보롬왓)
SAME_PLACE = ["길", "탐방로", "산책로", "정상", "군락", "입구", "해안", "전망대"]

# 자동 연결이 틀리거나 못 찾은 곳: {"우리 관광지명": "비짓제주 콘텐츠ID 또는 비짓제주 이름"}
# 연결을 막고 싶으면 값에 None. VisitJeju_Check.csv의 후보 열을 보고 채운다.
MANUAL = {
    "자구리담수욕장": "자구리공원",      # 같은 곳 (팀 확인 10/15)
    # "산방산랜드": None,               # 연결을 막을 때
}

# 이름 끝의 유형만 다른 같은 곳 (자구리담수욕장 = 자구리공원): 유형을 떼고 남은 이름이 같고 같은 리·동, 1.5km 안
TYPE_SUFFIX = ["담수욕장", "해수욕장", "해변", "해안", "공원", "유원지", "포구", "계곡"]
E_RADIUS_M = 1500

# 화면에 띄울 편의·접근성 항목 (alltag에서 이 단어와 정확히 같은 것만)
FACILITIES = ["장애인 화장실", "장애인 전용 주차장", "임산부 휴게시설", "유아휴게실", "수유실",
              "휠체어 대여", "유모차 대여", "공용주차장", "무료 WIFI", "실내", "실외"]


def clean_vj_name(s) -> str:
    """'성산일출봉(UNESCO 세계자연유산)[홍보관 등 실내미개방]' → 대괄호 안내문 제거 (괄호는 core_name이 처리)"""
    return re.sub(r"\s*\[.*?\]\s*", " ", str(s or "")).strip()


def facilities(alltag) -> str:
    tags = [t.strip() for t in str(alltag or "").split(",")]
    picked = [f for f in FACILITIES if f in tags]
    dur = next((t for t in tags if re.fullmatch(r"\d+시간\s*(미만|이상)?", t)), None)
    if dur:
        picked.append(f"소요 {dur}")
    return ",".join(picked)


def addr_parts(s):
    """지번주소 → (읍면동 키, 리 키, 지번 키). 없으면 빈 문자열.
    '제주특별자치도 서귀포시 남원읍 위미리 929-2' → ('서귀포시 남원읍', '서귀포시 남원읍 위미리', '서귀포시 남원읍 위미리 929-2')
    '제주특별자치도 제주시 도두일동 산 2'        → ('제주시 도두일동', '제주시 도두일동', '제주시 도두일동 산2')"""
    if not isinstance(s, str) or not s.strip():
        return "", "", ""
    t = re.sub(r"^\s*제주(특별자치도|도)?\s*", "", s.strip())
    t = re.sub(r"\(.*?\)", " ", t)
    tok = t.split()
    if len(tok) < 2 or not tok[0].endswith("시"):
        return "", "", ""
    city, i = tok[0], 1
    if not re.search(r"(읍|면|동|가)$", tok[i]):
        return "", "", ""
    emd = f"{city} {tok[i]}"
    ri = emd
    if tok[i].endswith(("읍", "면")) and i + 1 < len(tok) and tok[i + 1].endswith("리"):
        i += 1
        ri = f"{emd} {tok[i]}"
    rest = "".join(tok[i + 1:])
    m = re.match(r"(산)?\d+(-\d+)?", rest)
    lot = f"{ri} {m.group(0)}" if m else ""
    return emd, ri, lot


def distance_m(lat1, lon1, lat2, lon2) -> np.ndarray:
    R = 6371000.0
    lat1, lon1, lat2, lon2 = map(np.radians, (lat1[:, None], lon1[:, None], lat2[None, :], lon2[None, :]))
    a = np.sin((lat2 - lat1) / 2) ** 2 + np.cos(lat1) * np.cos(lat2) * np.sin((lon2 - lon1) / 2) ** 2
    return 2 * R * np.arcsin(np.sqrt(a))


def name_sim(a: str, b: str) -> float:
    if not a or not b:
        return 0.0
    return max(SequenceMatcher(None, a, b).ratio(), bigram_dice(a, b))


def stem(n: str) -> str:
    """'자구리담수욕장' → '자구리', '자구리공원' → '자구리' (유형 말을 뗀 이름)"""
    for suf in sorted(TYPE_SUFFIX, key=len, reverse=True):
        if n.endswith(suf) and len(n) - len(suf) >= 2:
            return n[: -len(suf)]
    return n


def grade(ct, cv, d, same_emd, same_ri, same_lot):
    """(우선순위, 이름) 또는 None. 우선순위가 작을수록 좋다."""
    if ct and cv:
        if ct == cv:
            limit = A_RADIUS_SHORT_M if len(ct) <= SHORT_LEN else A_RADIUS_M
            if d <= limit or same_emd:
                return (1, "A 이름일치")
        else:
            short, long_ = sorted((ct, cv), key=len)
            extra = long_.replace(short, "", 1)
            if len(short) >= 2 and short in long_ and not any(w in extra for w in OTHER_FACILITY):
                if d <= B_RADIUS_M or (same_ri and len(short) >= 3 and any(w in extra for w in SAME_PLACE)):
                    return (2, "B 이름포함")
            sim = name_sim(ct, cv)
            if (sim >= C_SIM_MIN and d <= C_RADIUS_M) or (sim >= C_SIM_SAME_RI and same_ri):
                return (3, "C 이름유사")
            if stem(ct) == stem(cv) and len(stem(ct)) >= 2 and same_ri and d <= E_RADIUS_M:
                return (4, "E 유형만다름")
    if same_lot:
        return (5, "D 지번일치")
    return None


def main():
    tour = pd.read_csv(CSV_DIR / "Tourist_Area.csv", encoding="utf-8-sig")
    vj = pd.read_csv(CSV_DIR / "VisitJeju_Places.csv", encoding="utf-8-sig")
    vj = vj.dropna(subset=["위도", "경도"]).reset_index(drop=True)

    ct = tour["장소명"].map(core_name).to_numpy()
    cv = vj["이름"].map(clean_vj_name).map(core_name).to_numpy()
    D = distance_m(tour["위도"].to_numpy(float), tour["경도"].to_numpy(float),
                   vj["위도"].to_numpy(float), vj["경도"].to_numpy(float))

    ta = [addr_parts(a) for a in tour["지번주소"]]
    # 비짓제주 지번주소가 비어 있으면 도로명주소에서 읍·면이라도 얻는다
    va = [addr_parts(a) if addr_parts(a)[0] else addr_parts(b)
          for a, b in zip(vj["지번주소"], vj.get("도로명주소", pd.Series([None] * len(vj))))]
    v_emd = np.array([x[0] for x in va])
    v_ri = np.array([x[1] for x in va])
    v_lot = np.array([x[2] for x in va])
    # 지번이 하나뿐인 곳만 D(지번일치)에 쓴다 (동백동산 안의 먼물깍처럼 한 지번에 여러 곳이면 제외)
    t_lot_n = pd.Series([x[2] for x in ta]).value_counts()
    v_lot_n = pd.Series(v_lot).value_counts()

    by_id = {str(r["콘텐츠ID"]): j for j, r in vj.iterrows()}
    vj_clean = vj["이름"].map(clean_vj_name).to_numpy()

    rows = []
    for i in range(len(tour)):
        name = tour.at[i, "장소명"]
        emd, ri, lot = ta[i]
        best = None   # ((우선순위, 이름), j)

        if name in MANUAL:
            key = MANUAL[name]
            j = None
            if key is not None:
                j = by_id.get(str(key))
                if j is None:   # 이름으로 적었으면: 이름(또는 핵심명)이 같은 것 중 가장 가까운 곳
                    same = np.where((vj_clean == clean_vj_name(key)) | (cv == core_name(clean_vj_name(key))))[0]
                    j = int(same[np.argmin(D[i, same])]) if len(same) else None
            if key is not None and j is None:
                print(f"  [직접지정 확인] '{name}' → '{key}'를 비짓제주 목록에서 못 찾았습니다.")
            best = ((0, "0 직접지정"), j) if j is not None else None
        else:
            cand = np.where(D[i] <= A_RADIUS_M)[0]
            if emd:
                cand = np.union1d(cand, np.where(v_emd == emd)[0])
            for j in cand:
                g = grade(ct[i], cv[j], float(D[i, j]),
                          bool(emd) and v_emd[j] == emd,
                          bool(ri) and v_ri[j] == ri,
                          bool(lot) and v_lot[j] == lot and t_lot_n.get(lot, 0) == 1 and v_lot_n.get(lot, 0) == 1)
                if g and (best is None or (g[0], D[i, j]) < (best[0][0], D[i, best[1]])):
                    best = (g, j)

        row = {"관광지_idx": i, "관광지명": name}
        if best:
            (_, kind), j = best
            v = vj.loc[j]
            row.update({"매칭유형": kind, "거리_m": round(float(D[i, j]), 1),
                        "비짓제주_이름": v["이름"], "콘텐츠ID": v["콘텐츠ID"], "태그": v["태그"],
                        "소개": v["소개"], "편의시설": facilities(v["전체태그"]),
                        "사진": v["사진"], "썸네일": v["썸네일"]})
        else:
            row["매칭유형"] = "미매칭"
        rows.append(row)

    out = pd.DataFrame(rows)
    out.to_csv(CSV_DIR / "Tourist_VisitJeju_Match.csv", index=False, encoding="utf-8-sig")
    ok = out["매칭유형"] != "미매칭"
    print(f"저장: csv/Tourist_VisitJeju_Match.csv · 관광지 {len(out)}곳 중 비짓제주 연결 {ok.sum()}곳 ({ok.mean():.1%})")
    print(out["매칭유형"].value_counts().to_string())

    # ---- 점검표: 웹에 나오는 관광지(제철 지수가 있는 곳) 전부 ----
    sl_path = CSV_DIR / "refined_seasonal_lift.csv"
    if not sl_path.exists():
        return
    sl = pd.read_csv(sl_path)
    sl = sl[~sl["관광지명"].str.contains("인증센터", na=False)]
    sl_ids = set(sl["관광지_idx"])
    review = set(out.loc[out["매칭유형"].astype(str).str[0].isin(["B", "C", "D", "E"]), "관광지_idx"])
    ids = sorted(sl_ids | review)

    check = []
    for i in ids:
        r = out.loc[i]
        if r["매칭유형"] == "미매칭":
            state = "연결 안 됨"
        elif pd.isna(r.get("사진")):
            state = "사진 없음(비짓제주에 사진이 없음)"
        elif str(r["매칭유형"]).startswith(("B", "C", "D", "E")):
            state = "검토 필요"
        else:
            state = "정상"
        item = {"관광지_idx": i, "관광지명": r["관광지명"], "추천카드_대상": "예" if i in sl_ids else "",
                "지번주소": tour.at[i, "지번주소"],
                "상태": state, "매칭유형": r["매칭유형"], "비짓제주_이름": r.get("비짓제주_이름"),
                "거리_m": r.get("거리_m")}
        if state != "정상":
            # 거리와 상관없이 이름이 가장 비슷한 비짓제주 후보 3개 (직접지정할 때 참고)
            sims = np.array([name_sim(ct[i], c) + (0.5 if ct[i] and c and (ct[i] in c or c in ct[i]) else 0)
                             for c in cv])
            for k, j in enumerate(np.argsort(-sims)[:3], 1):
                item[f"후보{k}"] = (f"{vj.at[j, '이름']} | {vj.at[j, '콘텐츠ID']} | "
                                    f"{int(D[i, j])}m | {vj.at[j, '지번주소']}")
        check.append(item)

    ck = pd.DataFrame(check)
    ck.to_csv(CSV_DIR / "VisitJeju_Check.csv", index=False, encoding="utf-8-sig")
    main_ck = ck[ck["추천카드_대상"] == "예"]
    print(f"\n[점검] 추천 카드에 나올 수 있는 관광지 {len(main_ck)}곳")
    print(main_ck["상태"].value_counts().to_string())
    for state in ["연결 안 됨", "사진 없음(비짓제주에 사진이 없음)", "검토 필요"]:
        sub = main_ck[main_ck["상태"] == state]
        if len(sub):
            print(f"  {state} {len(sub)}곳: " + ", ".join(
                f"{a}" + (f"→{b}" if isinstance(b, str) else "") for a, b in zip(sub["관광지명"], sub["비짓제주_이름"])))
    other = ck[(ck["추천카드_대상"] != "예")]
    if len(other):
        print(f"  (지도 팝업에만 쓰이는 곳 중 검토 필요 {len(other)}곳도 점검표에 함께 적음)")
    print("자세한 후보: csv/VisitJeju_Check.csv")


if __name__ == "__main__":
    main()
