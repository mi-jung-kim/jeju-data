import pandas as pd
import os

data_dir = r"C:\Users\justi\Desktop\제주공모\csv"

print("Loading Dataset B (제주 지역별 인기 장소)...")
# Load Dataset B (POI monthly visits)
df_b = pd.read_csv(os.path.join(data_dir, "제주 지역별 인기 장소.csv"), encoding='utf-8')

print("Loading Dataset A Match Table (Tourist_Nav_Match)...")
# Load Match Table
df_match = pd.read_csv(os.path.join(data_dir, "Tourist_Nav_Match.csv"), encoding='utf-8')

# Filter only matched ones
df_match_valid = df_match[df_match['매칭유형'] != '미매칭']

print("Merging Datasets...")
# Merge Dataset B with Match Table to assign attraction_id (관광지_idx)
df_merged = pd.merge(df_b, df_match_valid, left_on=['목적지명', '목적지주소'], right_on=['내비_목적지명', '내비_목적지주소'], how='inner')

print("Calculating Baseline B(y,m)...")
# Calculate total tourists per month (Baseline) using total visits from Dataset B
baseline_visits = df_b.groupby('주행일자(YYYYMM)')['관광객 도착 수'].sum().reset_index()
baseline_visits.rename(columns={'관광객 도착 수': '제주전체_관광객_방문'}, inplace=True)
total_baseline_visits = baseline_visits['제주전체_관광객_방문'].sum()
baseline_visits['B_ratio'] = baseline_visits['제주전체_관광객_방문'] / total_baseline_visits

print("Calculating S(p,y,m) and Seasonal Lift...")
# Calculate monthly visits for each attraction
attraction_monthly = df_merged.groupby(['관광지_idx', '관광지명', '주행일자(YYYYMM)'])['관광객 도착 수'].sum().reset_index()

# Filter out attractions with very low total visits to avoid noise (e.g. at least 100 visits)
attraction_total = attraction_monthly.groupby(['관광지_idx'])['관광객 도착 수'].sum().reset_index()
attraction_total.rename(columns={'관광객 도착 수': '관광지_총방문'}, inplace=True)
attraction_total = attraction_total[attraction_total['관광지_총방문'] >= 100]

attraction_monthly = pd.merge(attraction_monthly, attraction_total, on='관광지_idx')
attraction_monthly['S_ratio'] = attraction_monthly['관광객 도착 수'] / attraction_monthly['관광지_총방문']

# Calculate Seasonal Lift
final_df = pd.merge(attraction_monthly, baseline_visits, on='주행일자(YYYYMM)')
final_df['Seasonal_Lift'] = final_df['S_ratio'] / final_df['B_ratio']

# Let's inspect a natural tourist spot
spot_name = "비자림"
spot_data = final_df[final_df['관광지명'].str.contains(spot_name, na=False)].sort_values('주행일자(YYYYMM)')

if spot_data.empty:
    spot_name = "우도"
    spot_data = final_df[final_df['관광지명'].str.contains(spot_name, na=False)].sort_values('주행일자(YYYYMM)')

print(f"\n--- {spot_name} Seasonal Lift ---")
print(spot_data[['주행일자(YYYYMM)', '관광객 도착 수', 'S_ratio', 'B_ratio', 'Seasonal_Lift']])

# Find the peak month for this spot
if not spot_data.empty:
    peak_month = spot_data.loc[spot_data['Seasonal_Lift'].idxmax()]
    print(f"\n>> {spot_name}의 제철(Peak Month)은 {peak_month['주행일자(YYYYMM)']} 입니다. (Seasonal Lift: {peak_month['Seasonal_Lift']:.2f})")

final_df.to_csv(os.path.join(data_dir, "calculated_seasonal_lift.csv"), index=False, encoding='utf-8-sig')
print("\nAnalysis complete. Saved to calculated_seasonal_lift.csv")
