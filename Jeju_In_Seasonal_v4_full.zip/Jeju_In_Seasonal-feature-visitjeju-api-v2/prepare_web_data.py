"""
제철 지수 결과 → 웹 데이터(web_data.json)

바뀐 점
  - 경로를 이 파일 위치 기준으로 (어느 컴퓨터에서 돌려도 됨)
  - all_spots에 월별 제철 지수(monthly_sl)를 넣는다 → 지도에서 787곳 분포를 켤 때 핀 색이 나온다
    (예전 버전은 이 값을 만들지 않아 다시 돌리면 핀이 모두 회색이 됐다)
  - csv/Tourist_VisitJeju_Match.csv(match_visitjeju.py 결과)가 있으면 비짓제주 사진·태그·소개·편의시설을 넣는다
  - 웹이 읽는 web/static/data/ 와 static/data/ 에 바로 저장한다
"""
import json
from pathlib import Path

import pandas as pd

ROOT = Path(__file__).resolve().parent
CSV_DIR = ROOT / "csv"
OUT_FILES = [ROOT / "web" / "static" / "data" / "web_data.json", ROOT / "static" / "data" / "web_data.json"]
TOP_N = 10

df = pd.read_csv(CSV_DIR / "refined_seasonal_lift.csv")
match = pd.read_csv(CSV_DIR / "Tourist_Nav_Match.csv")

# Exclude non-attractions like '인증센터'
df = df[~df['관광지명'].str.contains('인증센터', na=False)]
df['month'] = df['주행일자(YYYYMM)'].astype(str).str[-2:].astype(int)

# Group by attraction and month (2024·2025 같은 달 평균)
agg = df.groupby(['관광지_idx', '관광지명', 'month']).agg({
    'Seasonal_Lift': 'mean',
    '관광객 도착 수': 'mean',
    '관광지_총방문': 'first'
}).reset_index()

coords = match[['관광지_idx', '관광지_위도', '관광지_경도', '관광지_지번주소', '내비_카테고리']].drop_duplicates(subset=['관광지_idx'])
agg = agg.merge(coords, on='관광지_idx', how='left')
agg = agg.dropna(subset=['관광지_위도', '관광지_경도'])

# 비짓제주 상세 정보 (있을 때만): match_visitjeju.py 결과를 관광지_idx로 붙인다
vj = {}
vj_path = CSV_DIR / "Tourist_VisitJeju_Match.csv"
if vj_path.exists():
    v = pd.read_csv(vj_path)
    v = v[v['매칭유형'] != '미매칭']

    def split(x, n):
        return [t.strip() for t in str(x).split(',') if t.strip() and str(x) != 'nan'][:n]

    for _, r in v.iterrows():
        vj[int(r['관광지_idx'])] = {
            'vjId': r['콘텐츠ID'],
            'tags': split(r['태그'], 4),
            'intro': r['소개'] if pd.notna(r['소개']) else None,
            'facilities': split(r['편의시설'], 6),
            'photo': {'url': r['사진'], 'thumb': r['썸네일'] if pd.notna(r['썸네일']) else r['사진']} if pd.notna(r['사진']) else None,
        }
    print(f"비짓제주 상세 정보 {len(vj)}곳 연결")
else:
    print("csv/Tourist_VisitJeju_Match.csv가 없어 비짓제주 정보 없이 만듭니다 (fetch_visitjeju.py → match_visitjeju.py 먼저).")


# Seasonal highlight tag generator
def get_season_tag(name, cat, month):
    if '동백' in name or month in [12, 1]:
        return "겨울 동백의 붉은 물결" if '동백' in name else "겨울 제주의 고요한 정취"
    if '산방산' in name or '유채' in name or month in [2, 3]:
        return "화사한 노란 유채꽃 명소" if ('산방산' in name or '서우' in name) else "봄기운이 움트는 명소"
    if '보롬왓' in name or '수국' in name or month in [5, 6]:
        return "초여름 싱그러운 수국·꽃밭"
    if '해변' in name or '해수욕' in name or '담수욕' in name or '워터' in name or month in [7, 8]:
        return "청량한 물놀이와 바다 쉼터"
    if '오름' in name or '산굼부리' in name or '핑크' in name or month in [10, 11]:
        return "은빛 억새와 가을 물결"
    if cat:
        return f"제철 맞은 {cat}"
    return "이달의 추천 관광지"


monthly_data = {}
for m in range(1, 13):
    sub = agg[agg['month'] == m].sort_values('Seasonal_Lift', ascending=False)
    top_items = []
    for rank, (_, row) in enumerate(sub.head(TOP_N).iterrows(), 1):
        item = {
            'rank': rank,
            'id': int(row['관광지_idx']),
            'name': row['관광지명'],
            'category': row['내비_카테고리'] if pd.notna(row['내비_카테고리']) else '자연명소',
            'address': row['관광지_지번주소'] if pd.notna(row['관광지_지번주소']) else '제주특별자치도',
            'lat': float(row['관광지_위도']),
            'lon': float(row['관광지_경도']),
            'seasonal_lift': round(float(row['Seasonal_Lift']), 2),
            'monthly_visits': int(round(float(row['관광객 도착 수']))),
            'total_visits': int(row['관광지_총방문']),
            'tag': get_season_tag(row['관광지명'], str(row['내비_카테고리']), m),
        }
        item.update(vj.get(int(row['관광지_idx']), {}))
        top_items.append(item)
    monthly_data[m] = top_items

# 전체 관광지 (지도 배경). 제철 지수가 있는 곳은 월별 값을 함께 넣는다.
monthly_sl = (agg.pivot_table(index='관광지_idx', columns='month', values='Seasonal_Lift')
                 .round(2))
all_spots = coords.dropna(subset=['관광지_위도', '관광지_경도'])
master = match[['관광지_idx', '관광지명']].drop_duplicates(subset=['관광지_idx'])
all_spots = all_spots.merge(master, on='관광지_idx', how='left')

all_spots_list = []
for _, row in all_spots.iterrows():
    idx = int(row['관광지_idx'])
    spot = {
        'id': idx,
        'name': row['관광지명'],
        'category': row['내비_카테고리'] if pd.notna(row['내비_카테고리']) else '관광지',
        'lat': float(row['관광지_위도']),
        'lon': float(row['관광지_경도']),
        'address': row['관광지_지번주소'] if pd.notna(row['관광지_지번주소']) else '',
    }
    if idx in monthly_sl.index:
        spot['monthly_sl'] = {str(m): float(v) for m, v in monthly_sl.loc[idx].dropna().items()}
    if idx in vj:
        spot['tags'] = vj[idx]['tags'][:2]
        if vj[idx]['photo']:
            spot['thumb'] = vj[idx]['photo']['thumb']
    all_spots_list.append(spot)

web_data = {'monthly': monthly_data, 'all_spots': all_spots_list}
for path in OUT_FILES:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(web_data, ensure_ascii=False, indent=2), encoding='utf-8')

print(f"저장: {', '.join(str(p.relative_to(ROOT)) for p in OUT_FILES)}")
print(f"월 {len(monthly_data)}개 · 지도 관광지 {len(all_spots_list)}곳 · 제철 지수 있는 곳 {sum('monthly_sl' in s for s in all_spots_list)}곳")
